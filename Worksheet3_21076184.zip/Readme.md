﻿# Web app/server that talks to the micro:bit to display some form of sensor data, button presses, and a visualization of the LED screen:


## Materials Required

-   micro:bit
-   USB cable

## Instructions
1.	Install the necessary software:
	-Visual Studio Code (VS Code)
	-Python extension for VS Code
	-Micro:bit extension for VS Code
2.	Connect the micro:bit to your computer via USB cable.
3.	Open VS Code and create a new Python file.
4.	Install the microbit module by running the following command in the terminal:
	-pip install microbit
5.	Import the necessary modules:
	-from microbit import *
	-from flask import Flask, render_template, request
6.	Create a Flask web app:
	-app = Flask(__name__)
7.	Define a route to handle the root URL:
	-@app.route('/')
	-def index():
	-return render_template('index.html')
8.	Create an HTML template for the web page. You can use the following template as a starting point:
	//refer to index.html file in Micro-bit directory
	//open the file in vscode
9.	Define a route to handle the /stream URL. This route will send real-time data from the micro:bit to the web page using SSE:
	//refer the python file in Micro-bit directory
	//open the file in vscode 
10.	Run the web app:
	-if __name__ == '__main__':
	- app.run(debug=True)
11.	Upload the following code to the micro:bit:
	
	from microbit import *

	while True:
 	   print('temperature: %d' % temperature())
 	   print('light: %d' % display.read_light_level())
 	   print('button_a: %d' % button_a.is_pressed())
  	   print('button_b: %d' % button_b.is_pressed())
  	   display.show(Image.HAPPY)
  	   sleep(0.1)

	//hex file is also located inside the directory

12.	Open a web browser and navigate to http://localhost:5000. You should see the web page with the sensor data and LED screen visualization.
13.	Hold down the buttons on the micro:bit and observe how the button data is displayed on the web page in real-time.
14.	Observe how the LED screen visualization changes on the micro:bit and the web page in real-time.


## Credits

This program was created by Ali Sharaf Ahmed as a personal project.
