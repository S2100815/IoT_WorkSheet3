from microbit import *
from flask import Flask, render_template, Response

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/stream')
def stream():
    def generate():
        while True:
            data = {
                'temperature': temperature(),
                'light': display.read_light_level(),
                'button_a': button_a.is_pressed(),
                'button_b': button_b.is_pressed(),
                'led_matrix': str(display.show(Image.HAPPY))
            }
            yield 'data: %s\n\n' % str(data)
            sleep(0.1)
    return Response(generate(), mimetype='text/event-stream')

if __name__ == '__main__':
    app.run(debug=True)
