# microbitstubs
Stubs for all the methods and classes within the Micro:Bit module, so that intellisense can be used with them in Visual Studio Code

Should make it more easy to teach Python programming with Visual Studio Code.
Used with: https://github.com/PhonicCanine/vscode-microbit