from microbit import *

while True:
    print('temperature: %d' % temperature())
    print('light: %d' % display.read_light_level())
    print('button_a: %d' % button_a.is_pressed())
    print('button_b: %d' % button_b.is_pressed())
    display.show(Image.HAPPY)
    sleep(0.1)